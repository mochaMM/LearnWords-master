package jp.co.learn.beans;

public class Word {

    private String hiragana;
    private String japanese;
    private String chinese;

    public String getHiragana() {
        return nullCheck(hiragana);
    }
    public void setHiragana(String hiragana) {
        this.hiragana = hiragana;
    }
    public String getJapanese() {
        return nullCheck(japanese);
    }
    public void setJapanese(String japanese) {
        this.japanese = japanese;
    }
    public String getChinese() {
        return nullCheck(chinese);
    }
    public void setChinese(String chinese) {
        this.chinese = chinese;
    }
    private String getHiraganaHtml() {
        if (!getJapanese().equals("") && !getHiragana().equals("")) {
            return "<font face='ＭＳ 明朝,SimSun,宋体' size='+1'>（</font>"
                    +"<font face='ＭＳ 明朝,SimSun,宋体' size='+1' color='#B40404'>"
                    + getHiragana()
                    + "</font>"
                    + "<font face='ＭＳ 明朝,SimSun,宋体' size='+1'>）</font>";
        }
        if (getJapanese().equals("") && !getHiragana().equals("")) {
            return "<font face='ＭＳ 明朝,SimSun,宋体' size='+1'>" + getHiragana() + "</font>";
        }
        return "";
    }
    private String getJapaneseHtml() {
        return "<font face='ＭＳ 明朝,SimSun,宋体' size='+1'>" + getJapanese() + "</font>";
    }
    private String getChineseHtml() {
        return "<font face='ＭＳ 明朝,SimSun,宋体' size='+1' color='#045FB4'>" + getChinese() + "</font>";
    }
    public String text() {
        return getJapanese() + "（" + getHiragana() + "）" + "  " + getChinese();
    }
    public String getjapaneseWithHiragana() {
        return getJapanese() + "（" + getHiragana() + "）";
    }
    public String textHtml() {
        return getjapaneseWithHiraganaHtml()
             + "&nbsp;&nbsp;"
             + getChineseHtml();
    }
    public String getjapaneseWithHiraganaHtml() {
        if (getHiragana().equals(japanese) || "".equals(japanese)) {
            return "<font face='ＭＳ 明朝,SimSun,宋体' size='+1'>" + getHiragana() + "</font>";
        }
        return getJapaneseHtml() + getHiraganaHtml();
    }
    private String nullCheck(String str) {
        if (str == null) {
            return "";
        } else {
            return str.trim();
        }
    }
}
