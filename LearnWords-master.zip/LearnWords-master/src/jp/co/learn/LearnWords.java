package jp.co.learn;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.FontUIResource;

import com.melloware.jintellitype.HotkeyListener;
import com.melloware.jintellitype.IntellitypeListener;
import com.melloware.jintellitype.JIntellitype;

import jp.co.learn.beans.Word;

/**
 * こっそり語学勉強ソフト。
 * 
 * @author 李＆宋
 */
public class LearnWords extends JFrame implements ActionListener, KeyListener, HotkeyListener, IntellitypeListener, Runnable {

    /**
     * シリアルナンバー。
     */
    static final long serialVersionUID = 1L;

    /**
     * メニュー。
     */
    JPopupMenu menubar = new JPopupMenu();

    /**
     * 単語表示ラベル。
     */
    JLabel label;

    /**
     * 単語位置。
     */
    int sec;

    /**
     * 辞書。
     */
    List<Word> wordList = new ArrayList<Word>();

    /**
     * 削除済単語リスト。
     */
    List<String> settingList = new ArrayList<String>();

    /**
     * 間隔時間。
     */
    int intTime = 8000;

    /**
     * デフォルト表示位置。
     */
    int intRight = 40, intDown = 20;

    /**
     * ラベルの高さ。
     */
    int CONTENT_LABEL_HEIGHT = 28;

    /**
     * 一時停止フラグ。
     */
    boolean pause = false;

    /**
     * 一時停止する前の表示状態。
     */
    boolean pauseBeforeHide = false;

    /**
     * 0 : 日本語
     * 1 : 日本語 + 中国語
     */
    int mode = 0;

    /**
     * 辞書名。
     */
    String currentDict;

    /**
     * DELキー押下フラグ。
     */
    boolean deletedFlag = false;

    /**
     *  ドラッグ＆ドロップ時の開始位置。
     */
    MouseEvent start;

    /**
     * プロパティ設定ファイル。
     */
    Properties properties;
    
    List<String> item = new ArrayList<String>();
    List<String> subItem = new ArrayList<String>();
    static List<String> urlList = new ArrayList<String>();
    String currentPathForSys = new File(".").getAbsoluteFile().getParent() + "\\" + "LearnWords";
    /**
     * プログラムの入口。
     */
    public static void main(String[] args) throws Exception {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        initGlobalFontSetting(new Font("メイリオ", 0, 12));
        new LearnWords();
    }

    public LearnWords() {
        addKeyListener(this);
        sec = 0;
        readProperties("jp_");
        setMenu("jp_");
        JPanel mainPanel = new JPanel();
        label = new JLabel();
        label.setBackground(Color.gray);
        label.setVerticalAlignment(JLabel.CENTER);
        info("Loading......");
        mainPanel.add(label);

        Container contentPane = getContentPane();
        contentPane.add(mainPanel, BorderLayout.LINE_START);

        WindowDrugMove mouseListener = new WindowDrugMove(this);
        // マウスを最初に掴んだ時
        addMouseListener(mouseListener);
        // マウスをドラッグした時
        addMouseMotionListener(mouseListener);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(intRight, intDown, 400, CONTENT_LABEL_HEIGHT);
        setAlwaysOnTop(true);
        setUndecorated(true);
        setBackground(new Color(0x0, true));
        setVisible(true);

        // プロパティファイルを読み込む。
        properties = new Properties();
        try {
            File settingFile = new File(currentPathForSys + "\\environment.ini");
            if (settingFile.exists()) {
                properties.load(new FileInputStream(settingFile));
            }
        } catch(Exception e) {}

        String dictName = properties.getProperty("DICT");
        if (dictName == null || "".equals(dictName)) {
            info("辞書を選択してください。");
        } else {
            if (!loadDictResource(dictName)) {
                info("辞書を選択してください。");
            }
        }
        try {
            // フォルダ作成
            File directory = new File(String.valueOf(currentPathForSys));
            if (!directory.exists()) {
                directory.mkdir();
            } 
        } catch (Exception e) {

        }
        
        
        try {
//            JIntellitype.getInstance().addHotKeyListener(this);
//            JIntellitype.getInstance().addIntellitypeListener(this);
//            JIntellitype.getInstance().registerHotKey(1, JIntellitype.MOD_ALT, (int)'S');
        } catch(Exception e) {
            e.printStackTrace();
        }

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                writeFile();
                JIntellitype.getInstance().cleanUp();
            }
        });

        Thread thread = new Thread(this);
        thread.start();
    }

    class WindowDrugMove implements MouseMotionListener, MouseListener {
        private Point loc;
        private Window window;

        public WindowDrugMove(Window window) {
            this.window = window;
        }
    
        public void mouseMoved(MouseEvent e) {
        }
        public void mouseDragged(MouseEvent e) {
            loc = window.getLocation(loc);
            int x = loc.x - start.getX() + e.getX();
            int y = loc.y - start.getY() + e.getY();
            window.setLocation(x, y);
        }
        public void mouseClicked(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON3) {
                return;
            }
            pause = !pause;
            pause(pause);
        }
        public void mouseEntered(MouseEvent e) {}
        public void mouseExited(MouseEvent e) {}
        public void mousePressed(MouseEvent e) {
            start = e;
            showPopup(e);
        }
        public void mouseReleased(MouseEvent e) {
            showPopup(e);
        }
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand() == "Open") {
            JFileChooser fileChooser = new JFileChooser();
            // 名前設定
            fileChooser.setDialogTitle("ファイルを選択してください。");
            // ディフォルトほうしき
            fileChooser.showOpenDialog(null);
            fileChooser.setVisible(true);
            // 全パス取得
            if (fileChooser.getSelectedFile() != null) {
                String filename = fileChooser.getSelectedFile().getAbsolutePath();
                readFile(filename);
            }
        } else if ("menu02_01".equals(e.getActionCommand())) {
            info("ランダム開始...");
            Collections.shuffle(wordList);
            return;
        } else if ("menu02_02".equals(e.getActionCommand())) {
            info("ランダム終了...");
            reRadom();
            return;
        } else if ("menu03_01".equals(e.getActionCommand())) {
            if (intTime >= 1000) {
                intTime = intTime + 1000;
            } else if (250 <= intTime && intTime < 1000) {
                intTime = intTime * 2;
            }
            String text = String.valueOf(intTime / 1000) + "秒に変更しました。";
            info(text);
            return;
        } else if ("menu03_02".equals(e.getActionCommand())) {
            if (intTime > 1000) {
                intTime = intTime - 1000;
            } else if (intTime >= 500) {
                intTime = intTime / 2;
            }
            String text = String.valueOf(intTime / 1000) + "秒に変更しました。";
            info(text);
            
        } else if (e.getActionCommand().startsWith("DICT_") && e.getSource() instanceof JMenuItem) {
            writeFile();
            pause(false);
            currentDict = e.getActionCommand().substring(5);
            loadDictResource(currentDict);
            if(wordList.isEmpty()){
            	loadDictResourceSelf(e.getActionCommand().substring(5));
            }
            sec = 0;
        }else if ("menu98_01".equals(e.getActionCommand())) {

            initGlobalFontSetting(new Font("メイリオ", 0, 12));
            readProperties("jp_");
            setMenu("jp_");
        } else if ("menu98_02".equals(e.getActionCommand())) {

            initGlobalFontSetting(new Font("メイリオ", 0, 12));
            readProperties("en_");
            setMenu("en_");
        } else if ("menu98_03".equals(e.getActionCommand())) {
            initGlobalFontSetting(new Font("SimSun", 0, 12));
            readProperties("ch_");
            setMenu("ch_");
        } else if ("menu98_04".equals(e.getActionCommand())) {

            initGlobalFontSetting(new Font("メイリオ", 0, 12));
            readProperties("jp_");
            setMenu("jp_");
        } else if ("menu98_05".equals(e.getActionCommand())) {

            initGlobalFontSetting(new Font("CJK Unified Ideographs", 0, 12));
            readProperties("ko_");
            setMenu("ko_");
        }

        if ("exit".equals(e.getActionCommand())) {
            int dialogButton = JOptionPane.YES_NO_OPTION;
            if (dialogButton == JOptionPane.YES_OPTION) {
                System.exit(NORMAL);
            }
        }
    }

    public void run() {
        try {
            start : do {
                if (wordList.size() == 0) {
                    Thread.sleep(1000);
                    continue start;
                }
                if (deletedFlag) {
                    deletedFlag = false;
                }
                // 削除済チェック
                do {
                    if (sec == wordList.size()) {
                        sec = 0;
                    }
                    if (settingList.contains(wordList.get(sec).getjapaneseWithHiragana())) {
                        sec++;
                    } else {
                        break;
                    }
                } while(true);
                // 辞書末尾チェック
                if (sec + 1 > wordList.size()) {
                    sec = 0;
                }
                // 単語表示
                label.setText("<html>" + wordList.get(sec).getjapaneseWithHiraganaHtml() + "</html>");
                modifySize();
                // スリープ
                if (!sleep(intTime / 2)) {
                    sec++;
                    continue start;
                }
                // 一時停止の状態でDelを押したら、次の単語へ。
                while(pause) {
                    if (deletedFlag) {
                        deletedFlag = false;
                        sec++;
                        continue start;
                    }
                    Thread.sleep(1000);
                }
                label.setText("<html>" + wordList.get(sec).textHtml() + "</html>");
                modifySize();
                if (!sleep(intTime / 2)) {
                    sec++;
                    continue start;
                }
                // 一時停止の状態でDelを押したら、次の単語へ。
                while (pause) {
                    if (deletedFlag) {
                        deletedFlag = false;
                        sec++;
                        continue start;
                    }
                    Thread.sleep(1000);
                }
                sec++;
            } while(true);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private boolean sleep(int time) throws InterruptedException {
        boolean result = true;
        for (int i = 0; i < 100; i++) {
            if (deletedFlag) {
                result = false;
                break;
            }
            Thread.sleep(time / 100);
        }
        return result;
    }

    public void modifySize() {
        label.setSize(label.getPreferredSize());
        setSize(new Dimension((int) getPreferredSize().getWidth(),
                (pause ? CONTENT_LABEL_HEIGHT + 2 : CONTENT_LABEL_HEIGHT)));
    }

    /**
     * 指定されたTXTファイルを読み込む。
     */
    public void readFile(String fileName) {

        wordList = new ArrayList<Word>();
        sec = 0;
        try {
            Files.lines(Paths.get(fileName)).forEachOrdered(s -> {
                if (null != s && s.trim().length() > 1) {
                    Word word = new Word();
                    String[] info = s.split("  ");
                    if (info.length > 0) {
                        word.setHiragana(info[0]);
                    }
                    if (info.length > 1) {
                        word.setJapanese(info[1]);
                    }
                    if (info.length > 2) {
                        word.setChinese(info[2]);
                    }
                    wordList.add(word);
                }
            });
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {

        // + KEY 繰り返す時間追加
        if (e.getKeyCode() == 107) {
            if (intTime >= 1000) {
                intTime = intTime + 1000;
            } else if (250 <= intTime && intTime < 1000) {
                intTime = intTime * 2;
            }
            outPutMsgOfchangTime();
        }
        // - KEY 繰り返す時間追加
        else if (e.getKeyCode() == 109) {
            if (intTime > 1000) {
                intTime = intTime - 1000;
            } else if (intTime >= 500) {

                intTime = intTime / 2;
            }
            
            outPutMsgOfchangTime();
        }
        // ESCキー 終了
        else if (e.getKeyCode() == 27) {
            writeFile();
            System.exit(NORMAL);
        }
        // SPACE ランダム開始
        else if (e.getKeyCode() == 32) {
            Collections.shuffle(wordList);
        }
        // CTRL ランダム終了
        else if (e.getKeyCode() == 17) {
            label.setText("ランダム終了");
            reRadom();
        }
        else if (e.getKeyCode() == KeyEvent.VK_DELETE) {
            if (wordList.size() > 0) {
                settingList.add(wordList.get(sec).getjapaneseWithHiragana());
                deletedFlag = true;
            }
        }
        // 右
        else if (e.getKeyCode() == 39) {
            sec++;
            if (sec == wordList.size()) {
                sec = 0;
            }
            // 削除済チェック
            do {
                if (settingList.contains(wordList.get(sec).getjapaneseWithHiragana())) {
                    sec++;
                    if (sec == wordList.size()) {
                        sec = 0;
                    }
                } else {
                    break;
                }
            } while(true);
            // 文字表示
            if (mode == 0) {
                label.setText("<html>" + wordList.get(sec).getjapaneseWithHiraganaHtml() + "</html>");
            } else {
                label.setText("<html>" + wordList.get(sec).textHtml() + "</html>");
            }
            modifySize();
        }
        // 下
        else if (e.getKeyCode() == 40) {
            if (mode != 1) {
                mode = 1;
                label.setText("<html>" + wordList.get(sec).textHtml() + "</html>");
                modifySize();
            }
        }
        // 上
        else if (e.getKeyCode() == 38) {
            if (mode != 0) {
                mode = 0;
                label.setText("<html>" + wordList.get(sec).getjapaneseWithHiraganaHtml() + "</html>");
                modifySize();
            }
        }
        // 左
        else if (e.getKeyCode() == 37) {
            sec--;
            if (sec < 0) {
                sec = wordList.size() - 1;
            }
            // 削除済チェック
            do {
                if (settingList.contains(wordList.get(sec).getjapaneseWithHiragana())) {
                    sec--;
                    if (sec < 0) {
                        sec = wordList.size() - 1;
                    }
                } else {
                    break;
                }
            } while(true);
            // 文字表示
            if (mode == 0) {
                label.setText("<html>" + wordList.get(sec).getjapaneseWithHiraganaHtml() + "</html>");
            } else {
                label.setText("<html>" + wordList.get(sec).textHtml() + "</html>");
            }
            modifySize();
        }
    }

    /**
     * ランダム解除 ランダムを解除する。
     */
    private void reRadom() {
        loadDictResource(properties.getProperty("DICT"));
    }

    

    /**
     * 削除済の単語をファイルに出力する。
     */
    public void writeFile() {
        if (currentDict == null || currentDict.trim().length() == 0 || settingList == null || settingList.size() == 0) {
            return;
        }
        try {
            String currentPath = new File(".").getAbsoluteFile().getParent();
            String fileName = currentPath + "\\src\\resources\\dicts.setting\\" + currentDict + ".txt";
            
            File settingFile = new File(fileName); 
            if (!settingFile.exists()) {
                Path file = Paths.get(fileName);
                if (!file.getParent().toFile().exists()) {
                    Files.createDirectory(file.getParent());
                }
                Files.createFile(file);
            }
            FileSystem fs = FileSystems.getDefault();
            Path outputPath = fs.getPath(fileName);
            BufferedWriter bw = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8, StandardOpenOption.WRITE);
            settingList.forEach(s -> {
                try {
                    bw.write(s + "\r\n");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            settingFile = new File(currentPath + "\\environment.ini");
            properties.store(new FileOutputStream(settingFile), "Comments");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean loadDictResource(String param) {
        properties.setProperty("DICT", param);
        try {
            settingList.clear();
            String currentPath = new File(".").getAbsoluteFile().getParent();
            String fileName = currentPath + "\\src\\resources\\dicts.setting\\" + param + ".txt";

            File settingFile = new File(fileName);
            if (settingFile.exists()) {
                Files.lines(Paths.get(fileName)).forEachOrdered(s -> {
                    if (null != s && s.trim().length() > 1) {
                        settingList.add(s);
                    }
                });
            }

            wordList.clear();
            fileName = currentPath + "\\src\\resources\\dicts\\" + param + ".txt";
            File dictFile = new File(fileName);
            if (!dictFile.exists()) {
                return false;
            }
            Files.lines(Paths.get(fileName)).forEachOrdered(s -> {
                if (null != s && s.trim().length() > 1) {
                    Word word = new Word();
                    String[] info = s.split("  ");
                    if (info.length > 0) {
                        word.setHiragana(info[0]);
                    }
                    if (info.length > 1) {
                        word.setJapanese(info[1]);
                    }
                    if (info.length > 2) {
                        word.setChinese(info[2]);
                    }
                    wordList.add(word);
                }
            });
            sec = 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
    
    
    /**
     * 自定義辞書を読み込む
     * @param param
     * @return
     */
    private boolean loadDictResourceSelf(String param) {
    	 properties.setProperty("DICT", param);
         try {
             String fileName = currentPathForSys + "\\" + param + ".txt";
             File dictFile = new File(fileName);
             if (!dictFile.exists()) {
                 return false;
             }
             Files.lines(Paths.get(fileName)).forEachOrdered(s -> {
                 if (null != s && s.trim().length() > 1) {
                     Word word = new Word();
                     String[] info = s.split("  ");
                     if (info.length > 0) {
                         word.setHiragana(info[0]);
                     }
                     if (info.length > 1) {
                         word.setJapanese(info[1]);
                     }
                     if (info.length > 2) {
                         word.setChinese(info[2]);
                     }
                     wordList.add(word);
                 }
             });
             sec = 0;
         } catch (Exception e) {
             e.printStackTrace();
         }
         return true;
    }
    

    private void showPopup(MouseEvent e) {
        if (e.isPopupTrigger()) {
          menubar.show(e.getComponent(), e.getX(), e.getY());
        }
    }

    public void onHotKey(int aIdentifier) {
       if (aIdentifier == 1) {
           if (isVisible()) {
               setVisible(false);
               pauseBeforeHide = pause;
               pause(true);
           } else {
               setVisible(true);
               pause = pauseBeforeHide;
               pause(pause);
           }
       }
    }

    /**
     * listen for intellitype play/pause command
     */
    public void onIntellitype(int aCommand) {
        switch (aCommand) {
        case JIntellitype.APPCOMMAND_MEDIA_PLAY_PAUSE:
            break;
        default:
            break;
        }
    }

    private void pause(boolean flag) {
        pause = flag;
        if (flag) {
            getRootPane().setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.RED));
            setBounds(getX(), getY(), getWidth(), CONTENT_LABEL_HEIGHT + 2);
        } else {
            getRootPane().setBorder((new EmptyBorder(0, 0, 0, 0)));
            setBounds(getX(), getY(), getWidth(), CONTENT_LABEL_HEIGHT);
        }
    }

    private void info(String msg) {
    	
        label.setText("<html><font face='ＭＳ 明朝,SimSun,宋体' size='+1' color='green'>" + msg + "</font></html>");
        modifySize();
    }

    public static void initGlobalFontSetting(Font fnt){
        FontUIResource fontRes = new FontUIResource(fnt);
        for (Enumeration keys = UIManager.getDefaults().keys(); keys.hasMoreElements();) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof FontUIResource)
                UIManager.put(key, fontRes);
        }
    }

    /**
     * メニュー設定
     */
    private void setMenu(String meum) {
        menubar = new JPopupMenu();
        menubar.removeAll();

        item.sort((p1, p2) -> p1.compareTo(p2));
        subItem.sort((p1, p2) -> p1.compareTo(p2));
        for (final String chapterText : item) {
            String key = chapterText.split("\\.")[0];
            if (key.contains(meum)) {
                JMenu chapterMenu = new JMenu(chapterText.split("\\.")[1]);
                for (String paragraphText : subItem) {
                    String subKey = paragraphText.split("\\.")[0];
                    if (subKey.contains(key)) {
						chapterMenu.add(paragraphText.split("\\.")[1]);
                        chapterMenu.getItem(chapterMenu.getItemCount() - 1).addActionListener(this);
                        chapterMenu.getItem(chapterMenu.getItemCount() - 1).setActionCommand(subKey.replace(meum, ""));
                    }
                }
                menubar.add(chapterMenu);
            }
        }
        
        File currentPath = new File(new File(".").getAbsoluteFile().getParent() + "\\src\\resources\\dicts\\");
        File[] files = currentPath.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                JMenu menuitem8_3 = new JMenu(file.getName());
                File[] dicts = file.listFiles();
                for (File dict : dicts) {
                    if (dict.isFile()) {
                    	String dictName = dict.getName().replaceAll(".txt", "");
                        JMenuItem menuItem = new JMenuItem(dictName);
                        menuItem.addActionListener(this);
                        menuItem.setActionCommand("DICT_" + file.getName() + "\\" + dictName);
                        menuitem8_3.add(menuItem);
                    }
                }
                menubar.add(menuitem8_3);
            } else {
            	String dictName = file.getName().replaceAll(".txt", "");
                JMenuItem menuItem = new JMenuItem(dictName);
                menuItem.addActionListener(this);
                menuItem.setActionCommand("DICT_" + dictName);
                menubar.add(menuItem);
            }
        }

        File currentPath1 = new File(new File(".").getAbsoluteFile().getParent() + "\\" + "LearnWords");
        File[] files1 = currentPath1.listFiles();
        for (File file : files1) {
            if (file.isDirectory()) {
                JMenu menuitem9_3 = new JMenu(file.getName());
                File[] dicts = file.listFiles();
                for (File dict : dicts) {
                    if (dict.isFile()) {
                    	String dictName = dict.getName().replaceAll(".txt", "");
                        JMenuItem menuItem = new JMenuItem(dictName);
                        menuItem.addActionListener(this);
                        menuItem.setActionCommand("DICT_" + file.getName() + "\\" + dictName);
                        menuitem9_3.add(menuItem);
                    }
                }
                menubar.add(menuitem9_3);
            } else {
            	String dictName = file.getName().replaceAll(".txt", "");
                JMenuItem menuItem = new JMenuItem(dictName);
                menuItem.addActionListener(this);
                menuItem.setActionCommand("DICT_" + dictName);
                menubar.add(menuItem);
            }
        }
        
        
        
        
        

    }
    
    /**
     * propertiesファイルを読んで、メニューの内容を取得する。
     *
     * @param languageType
     */
	public void readProperties(String languageType) {
		item.clear();
		subItem.clear();
		String file = "conf/LearnWordsMenu.properties";
		Properties props = new Properties();
		try {
			// InputStream in =
			// ClassLoader.getSystemClassLoader().getResourceAsStream(file);
			InputStream in = new BufferedInputStream(new FileInputStream(file));
			InputStreamReader isr = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			props.load(br);
			Enumeration en = props.propertyNames();
			while (en.hasMoreElements()) {
				String key = (String) en.nextElement();
				String value = props.getProperty(key);
				System.out.println(key);
				System.out.println(value);

				if (key.contains(languageType)) {
					if (key.length() == 9) {
						item.add(key + "." + value);
					} else {
						subItem.add(key + "." + value);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
 
	  /**
     * double click
     */
    public void mouseClicked(MouseEvent e) {

        if (e.getClickCount() == 2) {
            String strInternetAddressSwich = "";

            try {
            //言葉検索
                strInternetAddressSwich = readFile(currentPathForSys + "\\system\\system.ini", "internet_address");
                if (strInternetAddressSwich.equals("0")) {
                    Runtime.getRuntime()
                            .exec("C://Program Files//Google//Chrome//Application//chrome.exe http://www.google.com/search?q="
                                    + wordList.get(sec - 1) + "&ie=euc-jp" + "&hl=ja" + "&hl=ja");
                } else if (strInternetAddressSwich.equals("1")) {

                    Runtime.getRuntime()
                            .exec("C://Program Files//Google//Chrome//Application//chrome.exe  http://www.baidu.com/s?wd="
                                    + wordList.get(sec - 1) + "&ie=euc-jp" + "&hl=ja" + "&hl=ja");
                } else {
                    Runtime.getRuntime()
                            .exec("C://Program Files//Google//Chrome//Application//chrome.exe https://www.weblio.jp/content/"
                                    + wordList.get(sec - 1) + "&ie=euc-jp" + "&hl=ja" + "&hl=ja");

                }
                
                
                if (strInternetAddressSwich.equals("0")) {
                    Runtime.getRuntime()
                            .exec("C://Program Files//Google//Chrome//Application//chrome.exe http://www.google.com/search?q="
                                    + wordList.get(sec - 1) + "&ie=euc-jp" + "&hl=ja" + "&hl=ja");
                } else if (strInternetAddressSwich.equals("1")) {

                    Runtime.getRuntime()
                            .exec("C://Program Files//Google//Chrome//Application//chrome.exe http://www.baidu.com/s?wd="
                                    + wordList.get(sec - 1) + "&ie=euc-jp" + "&hl=ja" + "&hl=ja");
                } else {
                    Runtime.getRuntime()
                            .exec("C://Program Files//Google//Chrome//Application//chrome.exe https://www.weblio.jp/content/"
                                    + wordList.get(sec - 1) + "&ie=euc-jp" + "&hl=ja" + "&hl=ja");

                }
//                
//                
                if(urlList.size()!=0){

                    // URLを行う
                    Runtime.getRuntime()
                    .exec("C://Program Files//Internet Explorer//iexplore.exe "+urlList.get(sec-1));

                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
    
	/**
	 * 頻度変更の提示目一セージ
	 */
	private void outPutMsgOfchangTime() {
	    if (intTime < 1000) {
	        String text = String.valueOf(intTime) + "ミリ秒に変更しました。";
	        label.setText("<html><font face='ＭＳ 明朝,SimSun,宋体' size='+1' color='green'>" + text + "</font></html>");
	    } else {
	        String text = String.valueOf(intTime / 1000) + "秒に変更しました。";
	        label.setText("<html><font face='ＭＳ 明朝,SimSun,宋体' size='+1' color='green'>" + text + "</font></html>");
	    }
	}
	
	/**
	 * read file 指定されたTXTファイルを読む
	 *
	 * @return
	 * @return
	 *
	 * @return なし
	 */
	public String readFile(String fileName, String Keyword) {
	    try {
	        return Files.lines(Paths.get(fileName), StandardCharsets.UTF_8)
	                .filter(s -> (!s.trim().substring(0).equals("#") && s.contains("=") && s.contains(Keyword)))
	                .findFirst().toString().split("=")[1].replace("]", "");

	    } catch (IOException e1) {

	        return "0";
	    }
	}	
    @Override
    public void keyReleased(KeyEvent arg0) {
    }

    @Override
    public void keyTyped(KeyEvent arg0) {
    }
}